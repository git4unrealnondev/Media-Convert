This allows unmanic to use av1an to convert files into AV1 format.
